from src.scrapers.base_scraper import BaseScraper
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import re

class BusinessBrokerScraper(BaseScraper):
    """Scraper for BusinessBroker.net FSBO business listings"""
    
    def __init__(self, config):
        super().__init__(config)
        self.platform_config = config['platforms']['businessbroker']
        
    def scrape(self):
        """Scrape business listings from BusinessBroker.net"""
        all_leads = []
        
        # Search for businesses in target states
        for state in self.config['geo_targets']['states']:
            try:
                leads = self.scrape_state(state)
                all_leads.extend(leads)
                self.logger.info(f"Found {len(leads)} leads from {state}")
            except Exception as e:
                self.logger.error(f"Error scraping {state}: {str(e)}")
                continue
        
        return all_leads
    
    def scrape_state(self, state):
        """Scrape BusinessBroker.net for a specific state"""
        leads = []
        
        # BusinessBroker.net search URL
        search_url = "https://www.businessbroker.net/businesses-for-sale"
        
        # Map state names for search
        state_abbrev = {'Florida': 'FL', 'Michigan': 'MI'}
        abbrev = state_abbrev.get(state, state[:2].upper())
        
        params = {
            'state': abbrev,
            'sort': 'date_desc'
        }
        
        # Search first few pages
        for page in range(1, 3):  # First 2 pages
            if page > 1:
                params['page'] = page
            
            response = self.make_request(search_url, params=params)
            if not response:
                break
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find listing containers (try multiple selectors)
            listings = (soup.find_all('div', class_='listing-item') or 
                       soup.find_all('div', class_='business-listing') or
                       soup.find_all('article', class_='listing'))
            
            if not listings:
                self.logger.warning(f"No listings found on page {page} for {state}")
                break
            
            page_leads = 0
            for listing in listings:
                try:
                    lead = self.parse_listing(listing, search_url)
                    if lead and self.is_fsbo_listing(lead.get('description', ''), lead.get('listing_title', '')):
                        leads.append(lead)
                        page_leads += 1
                except Exception as e:
                    self.logger.error(f"Error parsing BusinessBroker listing: {str(e)}")
                    continue
            
            self.logger.info(f"Found {page_leads} FSBO leads on page {page}")
            
            if page_leads == 0:
                break
        
        return leads
    
    def parse_listing(self, listing_element, base_url=""):
        """Parse individual BusinessBroker.net listing"""
        try:
            # Extract title and URL
            title_element = (listing_element.find('a', class_='listing-title') or 
                           listing_element.find('h3') or 
                           listing_element.find('a'))
            
            if not title_element:
                return None
            
            title = self.clean_text(title_element.get_text())
            listing_url = urljoin(base_url, title_element.get('href', ''))
            
            # Extract price
            price_element = (listing_element.find('span', class_='price') or 
                           listing_element.find('div', class_='price') or
                           listing_element.find(string=re.compile(r'\$[\d,]+')))
            
            price = None
            if price_element:
                price_text = price_element if isinstance(price_element, str) else price_element.get_text()
                price = self.parse_price(price_text)
            
            # Extract location
            location_element = (listing_element.find('span', class_='location') or 
                              listing_element.find('div', class_='location'))
            location_text = location_element.get_text() if location_element else ""
            city, state = self.extract_location(location_text)
            
            # Get detailed description
            description = self.get_listing_description(listing_url)
            
            # Extract business name
            business_name = self.extract_business_name(title)
            
            lead = {
                'business_name': business_name,
                'listing_title': title,
                'platform': 'BusinessBroker.net',
                'industry': self.guess_industry(title, description),
                'price': price,
                'revenue': self.extract_revenue(description),
                'cash_flow': self.extract_cash_flow(description),
                'city': city,
                'state': state,
                'location': f"{city}, {state}" if city and state else location_text,
                'contact_name': None,
                'contact_email': None,
                'contact_phone': None,
                'url': listing_url,
                'description': description,
                'platform_specific': {}
            }
            
            return lead
            
        except Exception as e:
            self.logger.error(f"Error parsing BusinessBroker listing: {str(e)}")
            return None
    
    def get_listing_description(self, url):
        """Get full description from listing page"""
        try:
            response = self.make_request(url)
            if not response:
                return ""
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for description in various containers
            description_selectors = [
                'div.business-description',
                'div.listing-description', 
                'div.description',
                'section.description',
                'div.content'
            ]
            
            description = ""
            for selector in description_selectors:
                element = soup.select_one(selector)
                if element:
                    description = self.clean_text(element.get_text())
                    break
            
            return description[:2000]  # Limit length
            
        except Exception as e:
            self.logger.error(f"Error getting description from {url}: {str(e)}")
            return ""
    
    def is_fsbo_listing(self, description, title):
        """Check if listing appears to be FSBO"""
        text = f"{title} {description}".lower()
        
        # Strong FSBO indicators
        strong_fsbo = [
            'owner selling', 'no broker', 'direct from owner', 'fsbo',
            'for sale by owner', 'contact owner directly', 'self-represented'
        ]
        
        # Weak FSBO indicators
        weak_fsbo = [
            'motivated seller', 'owner financing', 'private sale',
            'direct contact', 'no commission'
        ]
        
        # Broker indicators
        broker_indicators = [
            'broker protected', 'listing broker', 'exclusive listing',
            'broker required', 'agent contact', 'represented by'
        ]
        
        strong_fsbo_count = sum(1 for indicator in strong_fsbo if indicator in text)
        weak_fsbo_count = sum(1 for indicator in weak_fsbo if indicator in text)
        broker_count = sum(1 for indicator in broker_indicators if indicator in text)
        
        # Strong FSBO indicators override broker indicators
        if strong_fsbo_count > 0:
            return True
        
        # If broker indicators but no FSBO indicators, likely not FSBO
        if broker_count > 0 and (strong_fsbo_count + weak_fsbo_count) == 0:
            return False
        
        # Weak FSBO indicators are positive
        if weak_fsbo_count > 0:
            return True
        
        # Default to including for manual review
        return True
    
    def extract_business_name(self, title):
        """Extract business name from title"""
        # Remove sale-related phrases
        business_name = re.sub(r'\b(for sale|business|sale|selling|established|profitable)\b', '', title, flags=re.IGNORECASE)
        business_name = re.sub(r'\s+', ' ', business_name).strip()
        return business_name or title
    
    def guess_industry(self, title, description):
        """Guess industry from title and description"""
        text = f"{title} {description}".lower()
        
        # Industry mapping
        industries = {
            'restaurant': ['restaurant', 'cafe', 'diner', 'food service', 'catering'],
            'retail': ['retail', 'store', 'shop', 'boutique', 'merchandise'],
            'automotive': ['automotive', 'auto', 'car wash', 'detailing'],
            'healthcare': ['medical', 'dental', 'healthcare', 'clinic', 'practice'],
            'beauty': ['salon', 'spa', 'beauty', 'barber', 'nail'],
            'fitness': ['gym', 'fitness', 'yoga', 'personal training'],
            'cleaning': ['cleaning', 'janitorial', 'maid service'],
            'landscaping': ['landscaping', 'lawn care', 'tree service'],
            'construction': ['construction', 'contractor', 'renovation'],
            'transportation': ['transportation', 'delivery', 'logistics'],
            'manufacturing': ['manufacturing', 'production', 'assembly'],
            'technology': ['technology', 'software', 'IT', 'computer'],
            'education': ['education', 'school', 'training', 'tutoring'],
            'entertainment': ['entertainment', 'gaming', 'recreation']
        }
        
        for industry, keywords in industries.items():
            if any(keyword in text for keyword in keywords):
                return industry
        
        return 'Other'
    
    def extract_revenue(self, description):
        """Extract revenue from description"""
        if not description:
            return None
        
        patterns = [
            r'annual revenue[:\s]*\$?([0-9,]+)',
            r'yearly revenue[:\s]*\$?([0-9,]+)',
            r'gross revenue[:\s]*\$?([0-9,]+)',
            r'sales[:\s]*\$?([0-9,]+)',
            r'revenue[:\s]*\$?([0-9,]+)'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, description.lower())
            if match:
                return self.parse_price(match.group(1))
        
        return None
    
    def extract_cash_flow(self, description):
        """Extract cash flow from description"""
        if not description:
            return None
        
        patterns = [
            r'cash flow[:\s]*\$?([0-9,]+)',
            r'net income[:\s]*\$?([0-9,]+)',
            r'profit[:\s]*\$?([0-9,]+)',
            r'earnings[:\s]*\$?([0-9,]+)',
            r'sde[:\s]*\$?([0-9,]+)'  # Seller's Discretionary Earnings
        ]
        
        for pattern in patterns:
            match = re.search(pattern, description.lower())
            if match:
                return self.parse_price(match.group(1))
        
        return None

