from src.scrapers.base_scraper import BaseScraper
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import re

class FlippaScraper(BaseScraper):
    """Scraper for Flippa online business listings"""
    
    def __init__(self, config):
        super().__init__(config)
        self.platform_config = config['platforms']['flippa']
        
    def scrape(self):
        """Scrape business listings from Flippa"""
        all_leads = []
        
        try:
            leads = self.scrape_flippa_listings()
            all_leads.extend(leads)
            self.logger.info(f"Found {len(leads)} leads from Flippa")
        except Exception as e:
            self.logger.error(f"Error scraping Flippa: {str(e)}")
        
        return all_leads
    
    def scrape_flippa_listings(self):
        """Scrape Flippa business listings"""
        leads = []
        
        # Flippa search URL for businesses
        search_url = "https://flippa.com/search"
        
        params = {
            'filter[property_type][]': 'business',
            'filter[seller_type][]': 'owner',
            'sort': 'newest'
        }
        
        # Search first few pages
        for page in range(1, 3):  # First 2 pages
            if page > 1:
                params['page'] = page
            
            response = self.make_request(search_url, params=params)
            if not response:
                break
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find listing containers
            listings = (soup.find_all('div', class_='listing-item') or 
                       soup.find_all('article', class_='listing') or
                       soup.find_all('div', class_='property-card'))
            
            if not listings:
                self.logger.warning(f"No listings found on page {page}")
                break
            
            page_leads = 0
            for listing in listings:
                try:
                    lead = self.parse_listing(listing, "https://flippa.com")
                    if lead:
                        leads.append(lead)
                        page_leads += 1
                except Exception as e:
                    self.logger.error(f"Error parsing Flippa listing: {str(e)}")
                    continue
            
            self.logger.info(f"Found {page_leads} leads on page {page}")
            
            if page_leads == 0:
                break
        
        return leads
    
    def parse_listing(self, listing_element, base_url=""):
        """Parse individual Flippa listing"""
        try:
            # Extract title and URL
            title_element = (listing_element.find('a', class_='listing-title') or 
                           listing_element.find('h3') or 
                           listing_element.find('a'))
            
            if not title_element:
                return None
            
            title = self.clean_text(title_element.get_text())
            listing_url = urljoin(base_url, title_element.get('href', ''))
            
            # Extract price (current bid or buy-it-now price)
            price_element = (listing_element.find('span', class_='price') or 
                           listing_element.find('div', class_='price') or
                           listing_element.find('span', class_='current-bid'))
            
            price = None
            if price_element:
                price_text = price_element.get_text()
                price = self.parse_price(price_text)
            
            # Extract revenue information
            revenue_element = (listing_element.find('span', class_='revenue') or
                             listing_element.find('div', class_='monthly-revenue'))
            revenue = None
            if revenue_element:
                revenue_text = revenue_element.get_text()
                monthly_revenue = self.parse_price(revenue_text)
                if monthly_revenue:
                    revenue = monthly_revenue * 12  # Convert to annual
            
            # Extract profit/cash flow
            profit_element = (listing_element.find('span', class_='profit') or
                            listing_element.find('div', class_='monthly-profit'))
            cash_flow = None
            if profit_element:
                profit_text = profit_element.get_text()
                monthly_profit = self.parse_price(profit_text)
                if monthly_profit:
                    cash_flow = monthly_profit * 12  # Convert to annual
            
            # Get detailed description
            description = self.get_listing_description(listing_url)
            
            # Extract business type/category
            category_element = listing_element.find('span', class_='category')
            category = category_element.get_text() if category_element else ""
            
            # Extract business name
            business_name = self.extract_business_name(title)
            
            lead = {
                'business_name': business_name,
                'listing_title': title,
                'platform': 'Flippa',
                'industry': self.map_flippa_category(category, title, description),
                'price': price,
                'revenue': revenue,
                'cash_flow': cash_flow,
                'city': None,  # Online businesses typically don't have specific cities
                'state': None,
                'location': 'Online Business',
                'contact_name': None,
                'contact_email': None,
                'contact_phone': None,
                'url': listing_url,
                'description': description,
                'platform_specific': {
                    'category': category,
                    'business_type': 'online'
                }
            }
            
            return lead
            
        except Exception as e:
            self.logger.error(f"Error parsing Flippa listing: {str(e)}")
            return None
    
    def get_listing_description(self, url):
        """Get full description from listing page"""
        try:
            response = self.make_request(url)
            if not response:
                return ""
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for description in various containers
            description_selectors = [
                'div.listing-description',
                'div.description',
                'section.description',
                'div.property-description',
                'div.business-overview'
            ]
            
            description = ""
            for selector in description_selectors:
                element = soup.select_one(selector)
                if element:
                    description = self.clean_text(element.get_text())
                    break
            
            return description[:2000]  # Limit length
            
        except Exception as e:
            self.logger.error(f"Error getting description from {url}: {str(e)}")
            return ""
    
    def extract_business_name(self, title):
        """Extract business name from title"""
        # Remove common Flippa-specific phrases
        business_name = re.sub(r'\b(for sale|auction|buy it now|established|profitable)\b', '', title, flags=re.IGNORECASE)
        business_name = re.sub(r'\s+', ' ', business_name).strip()
        return business_name or title
    
    def map_flippa_category(self, category, title, description):
        """Map Flippa category to our industry categories"""
        text = f"{category} {title} {description}".lower()
        
        # Flippa-specific category mapping
        flippa_mapping = {
            'ecommerce': ['ecommerce', 'e-commerce', 'online store', 'shopify', 'amazon fba', 'dropshipping'],
            'saas': ['saas', 'software', 'app', 'platform', 'subscription'],
            'content': ['blog', 'website', 'content', 'affiliate', 'adsense'],
            'marketplace': ['marketplace', 'directory', 'classifieds'],
            'service': ['service', 'agency', 'consulting', 'freelance'],
            'gaming': ['gaming', 'game', 'mobile game'],
            'crypto': ['crypto', 'blockchain', 'bitcoin', 'nft'],
            'social': ['social', 'community', 'forum', 'social media'],
            'education': ['education', 'course', 'training', 'learning'],
            'health': ['health', 'fitness', 'medical', 'wellness'],
            'finance': ['finance', 'fintech', 'trading', 'investment'],
            'travel': ['travel', 'booking', 'tourism', 'hotel'],
            'real estate': ['real estate', 'property', 'rental'],
            'food': ['food', 'recipe', 'restaurant', 'delivery']
        }
        
        for industry, keywords in flippa_mapping.items():
            if any(keyword in text for keyword in keywords):
                return industry
        
        # Default mapping for online businesses
        if 'online' in text or 'website' in text or 'digital' in text:
            return 'ecommerce'
        
        return 'Other'

