from src.scrapers.base_scraper import BaseScraper
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import re

class BizBuySellScraper(BaseScraper):
    """Scraper for BizBuySell FSBO business listings"""
    
    def __init__(self, config):
        super().__init__(config)
        self.platform_config = config['platforms']['bizbuysell']
        
    def scrape(self):
        """Scrape business listings from BizBuySell"""
        all_leads = []
        
        # Search for businesses in target states
        for state in self.config['geo_targets']['states']:
            try:
                leads = self.scrape_state(state)
                all_leads.extend(leads)
                self.logger.info(f"Found {len(leads)} leads from {state}")
            except Exception as e:
                self.logger.error(f"Error scraping {state}: {str(e)}")
                continue
        
        return all_leads
    
    def scrape_state(self, state):
        """Scrape BizBuySell for a specific state"""
        leads = []
        
        # BizBuySell search URL with state filter
        search_url = "https://www.bizbuysell.com/businesses-for-sale"
        
        # Map state names to abbreviations for URL
        state_abbrev = {'Florida': 'FL', 'Michigan': 'MI'}
        abbrev = state_abbrev.get(state, state[:2].upper())
        
        params = {
            'state': abbrev,
            'sort': 'newest',
            'page': 1
        }
        
        # Search multiple pages
        for page in range(1, 4):  # First 3 pages
            params['page'] = page
            
            response = self.make_request(search_url, params=params)
            if not response:
                break
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find listing containers
            listings = soup.find_all('div', class_='business-card')
            if not listings:
                # Try alternative selector
                listings = soup.find_all('article', class_='listing-item')
            
            if not listings:
                self.logger.warning(f"No listings found on page {page} for {state}")
                break
            
            page_leads = 0
            for listing in listings:
                try:
                    lead = self.parse_listing(listing, search_url)
                    if lead and self.is_fsbo_listing(lead.get('description', ''), lead.get('listing_title', '')):
                        leads.append(lead)
                        page_leads += 1
                except Exception as e:
                    self.logger.error(f"Error parsing BizBuySell listing: {str(e)}")
                    continue
            
            self.logger.info(f"Found {page_leads} FSBO leads on page {page}")
            
            # If no leads found on this page, stop pagination
            if page_leads == 0:
                break
        
        return leads
    
    def parse_listing(self, listing_element, base_url=""):
        """Parse individual BizBuySell listing"""
        try:
            # Extract title and URL
            title_element = listing_element.find('a', class_='business-title') or listing_element.find('h3')
            if not title_element:
                title_element = listing_element.find('a')
            
            if not title_element:
                return None
            
            title = self.clean_text(title_element.get_text())
            listing_url = urljoin(base_url, title_element.get('href', ''))
            
            # Extract price
            price_element = listing_element.find('span', class_='price') or listing_element.find('div', class_='price')
            if not price_element:
                # Look for any element containing price
                price_element = listing_element.find(string=re.compile(r'\$[\d,]+'))
            
            price = None
            if price_element:
                price_text = price_element if isinstance(price_element, str) else price_element.get_text()
                price = self.parse_price(price_text)
            
            # Extract location
            location_element = listing_element.find('span', class_='location') or listing_element.find('div', class_='location')
            location_text = location_element.get_text() if location_element else ""
            city, state = self.extract_location(location_text)
            
            # Extract revenue and cash flow if available
            revenue = self.extract_financial_info(listing_element, 'revenue')
            cash_flow = self.extract_financial_info(listing_element, 'cash-flow')
            
            # Get detailed description
            description = self.get_listing_description(listing_url)
            
            # Extract business name
            business_name = self.extract_business_name(title)
            
            lead = {
                'business_name': business_name,
                'listing_title': title,
                'platform': 'BizBuySell',
                'industry': self.guess_industry(title, description),
                'price': price,
                'revenue': revenue,
                'cash_flow': cash_flow,
                'city': city,
                'state': state,
                'location': f"{city}, {state}" if city and state else location_text,
                'contact_name': None,  # Usually not shown in listings
                'contact_email': None,
                'contact_phone': None,
                'url': listing_url,
                'description': description,
                'platform_specific': {
                    'listing_id': self.extract_listing_id(listing_url)
                }
            }
            
            return lead
            
        except Exception as e:
            self.logger.error(f"Error parsing BizBuySell listing: {str(e)}")
            return None
    
    def get_listing_description(self, url):
        """Get full description from listing page"""
        try:
            response = self.make_request(url)
            if not response:
                return ""
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for description in various possible containers
            description_selectors = [
                'div.business-description',
                'div.description',
                'section.description',
                'div.listing-description',
                'div.content-description'
            ]
            
            description = ""
            for selector in description_selectors:
                element = soup.select_one(selector)
                if element:
                    description = self.clean_text(element.get_text())
                    break
            
            # If no specific description found, try to get general content
            if not description:
                content_div = soup.find('div', class_='listing-content') or soup.find('main')
                if content_div:
                    # Remove navigation and sidebar elements
                    for unwanted in content_div.find_all(['nav', 'aside', 'footer', 'header']):
                        unwanted.decompose()
                    description = self.clean_text(content_div.get_text())
            
            return description[:2000]  # Limit description length
            
        except Exception as e:
            self.logger.error(f"Error getting description from {url}: {str(e)}")
            return ""
    
    def is_fsbo_listing(self, description, title):
        """Check if listing appears to be FSBO based on description"""
        text = f"{title} {description}".lower()
        
        # FSBO indicators
        fsbo_indicators = [
            'owner selling', 'no broker', 'direct from owner', 'fsbo',
            'for sale by owner', 'contact owner', 'self-represented',
            'private sale', 'owner financing', 'motivated owner'
        ]
        
        # Broker indicators (negative signals)
        broker_indicators = [
            'broker protected', 'listing broker', 'exclusive listing',
            'broker required', 'agent contact', 'brokerage'
        ]
        
        # Check for FSBO indicators
        fsbo_score = sum(1 for indicator in fsbo_indicators if indicator in text)
        broker_score = sum(1 for indicator in broker_indicators if indicator in text)
        
        # If strong broker presence and no FSBO indicators, likely not FSBO
        if broker_score > 1 and fsbo_score == 0:
            return False
        
        # If any FSBO indicators, likely FSBO
        if fsbo_score > 0:
            return True
        
        # Default to including (can be filtered later)
        return True
    
    def extract_business_name(self, title):
        """Extract business name from title"""
        # Remove common business-for-sale phrases
        business_name = re.sub(r'\b(business for sale|for sale|established|profitable)\b', '', title, flags=re.IGNORECASE)
        business_name = re.sub(r'\s+', ' ', business_name).strip()
        return business_name or title
    
    def guess_industry(self, title, description):
        """Guess industry based on title and description"""
        text = f"{title} {description}".lower()
        
        industry_keywords = {
            'restaurant': ['restaurant', 'cafe', 'diner', 'bistro', 'eatery', 'food service'],
            'retail': ['retail', 'store', 'shop', 'boutique'],
            'automotive': ['automotive', 'auto', 'car', 'vehicle'],
            'healthcare': ['medical', 'dental', 'healthcare', 'clinic'],
            'beauty': ['salon', 'spa', 'beauty', 'barber'],
            'fitness': ['gym', 'fitness', 'yoga', 'martial arts'],
            'education': ['school', 'training', 'education', 'tutoring'],
            'manufacturing': ['manufacturing', 'production', 'factory'],
            'service': ['service', 'consulting', 'professional'],
            'technology': ['technology', 'software', 'IT', 'tech'],
            'real estate': ['real estate', 'property', 'realty'],
            'construction': ['construction', 'contractor', 'building'],
            'transportation': ['transportation', 'logistics', 'shipping', 'delivery']
        }
        
        for industry, keywords in industry_keywords.items():
            if any(keyword in text for keyword in keywords):
                return industry
        
        return 'Other'
    
    def extract_financial_info(self, listing_element, info_type):
        """Extract financial information from listing element"""
        try:
            # Look for financial info in various formats
            selectors = [
                f'span.{info_type}',
                f'div.{info_type}',
                f'[data-{info_type}]'
            ]
            
            for selector in selectors:
                element = listing_element.select_one(selector)
                if element:
                    return self.parse_price(element.get_text())
            
            return None
            
        except Exception:
            return None
    
    def extract_listing_id(self, url):
        """Extract listing ID from URL"""
        try:
            # BizBuySell URLs typically have ID in path
            path_parts = urlparse(url).path.split('/')
            for part in path_parts:
                if part.isdigit():
                    return part
            return None
        except Exception:
            return None

