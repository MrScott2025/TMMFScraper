from src.scrapers.base_scraper import BaseScraper
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import re

class CraigslistScraper(BaseScraper):
    """Scraper for Craigslist business-for-sale listings"""
    
    def __init__(self, config):
        super().__init__(config)
        self.platform_config = config['platforms']['craigslist']
        
    def scrape(self):
        """Scrape business listings from Craigslist"""
        all_leads = []
        
        for region in self.platform_config['regions']:
            try:
                leads = self.scrape_region(region)
                all_leads.extend(leads)
                self.logger.info(f"Found {len(leads)} leads from {region}")
            except Exception as e:
                self.logger.error(f"Error scraping {region}: {str(e)}")
                continue
        
        return all_leads
    
    def scrape_region(self, region):
        """Scrape a specific Craigslist region"""
        leads = []
        base_url = f"https://{region}.craigslist.org"
        search_url = f"{base_url}/search/bfs"
        
        # Add search parameters for FSBO keywords
        params = {
            'query': ' OR '.join(self.platform_config['keywords'][:2]),  # Limit to avoid too complex query
            'sort': 'date'
        }
        
        response = self.make_request(search_url, params=params)
        if not response:
            return leads
        
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Find listing containers
        listings = soup.find_all('li', class_='cl-search-result')
        
        for listing in listings[:20]:  # Limit per region to avoid overwhelming
            try:
                lead = self.parse_listing(listing, base_url)
                if lead:
                    leads.append(lead)
            except Exception as e:
                self.logger.error(f"Error parsing listing: {str(e)}")
                continue
        
        return leads
    
    def parse_listing(self, listing_element, base_url=""):
        """Parse individual Craigslist listing"""
        try:
            # Extract title and URL
            title_element = listing_element.find('a', class_='cl-app-anchor')
            if not title_element:
                return None
            
            title = self.clean_text(title_element.get_text())
            listing_url = urljoin(base_url, title_element.get('href', ''))
            
            # Extract price
            price_element = listing_element.find('span', class_='priceinfo')
            price_text = price_element.get_text() if price_element else None
            price = self.parse_price(price_text)
            
            # Extract location
            location_element = listing_element.find('span', class_='location')
            location_text = location_element.get_text() if location_element else ""
            city, state = self.extract_location(location_text)
            
            # Get detailed description by visiting the listing page
            description = self.get_listing_description(listing_url)
            
            # Extract contact info from description
            contact_info = self.extract_contact_info(description)
            
            # Check if this looks like an FSBO listing
            if not self.is_fsbo_listing(title, description):
                return None
            
            lead = {
                'business_name': self.extract_business_name(title),
                'listing_title': title,
                'platform': 'Craigslist',
                'industry': self.guess_industry(title, description),
                'price': price,
                'revenue': self.extract_revenue(description),
                'cash_flow': self.extract_cash_flow(description),
                'city': city,
                'state': state,
                'location': f"{city}, {state}" if city and state else location_text,
                'contact_name': contact_info.get('name'),
                'contact_email': contact_info.get('email'),
                'contact_phone': contact_info.get('phone'),
                'url': listing_url,
                'description': description,
                'platform_specific': {
                    'region': base_url.split('//')[1].split('.')[0]
                }
            }
            
            return lead
            
        except Exception as e:
            self.logger.error(f"Error parsing Craigslist listing: {str(e)}")
            return None
    
    def get_listing_description(self, url):
        """Get full description from listing page"""
        try:
            response = self.make_request(url)
            if not response:
                return ""
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find the posting body
            body_element = soup.find('section', id='postingbody')
            if body_element:
                # Remove the QR code text
                qr_text = body_element.find('div', class_='print-qrcode-container')
                if qr_text:
                    qr_text.decompose()
                
                return self.clean_text(body_element.get_text())
            
            return ""
            
        except Exception as e:
            self.logger.error(f"Error getting description from {url}: {str(e)}")
            return ""
    
    def is_fsbo_listing(self, title, description):
        """Check if listing appears to be FSBO"""
        text = f"{title} {description}".lower()
        
        # FSBO indicators
        fsbo_keywords = [
            'owner', 'no broker', 'no agent', 'direct', 'fsbo', 
            'for sale by owner', 'selling myself', 'private sale'
        ]
        
        # Broker indicators (negative)
        broker_keywords = [
            'broker', 'agent', 'realtor', 'brokerage', 'listing agent'
        ]
        
        has_fsbo = any(keyword in text for keyword in fsbo_keywords)
        has_broker = any(keyword in text for keyword in broker_keywords)
        
        # If it has broker keywords but no FSBO keywords, likely not FSBO
        if has_broker and not has_fsbo:
            return False
        
        # If it has FSBO keywords, likely FSBO
        if has_fsbo:
            return True
        
        # Default to True for business-for-sale section (most are FSBO)
        return True
    
    def extract_business_name(self, title):
        """Extract business name from title"""
        # Remove common sale-related words to get business name
        title = re.sub(r'\b(for sale|business|sale|selling|sold)\b', '', title, flags=re.IGNORECASE)
        title = re.sub(r'[^\w\s]', '', title)  # Remove special characters
        return self.clean_text(title)
    
    def guess_industry(self, title, description):
        """Guess industry based on title and description"""
        text = f"{title} {description}".lower()
        
        industry_keywords = {
            'car wash': ['car wash', 'auto wash', 'vehicle wash'],
            'detailing': ['detailing', 'auto detail', 'car detail'],
            'cleaning': ['cleaning', 'janitorial', 'maid service'],
            'restaurant': ['restaurant', 'cafe', 'diner', 'eatery'],
            'pizza': ['pizza', 'pizzeria'],
            'convenience store': ['convenience', 'corner store', 'mini mart'],
            'gas station': ['gas station', 'fuel', 'petrol'],
            'laundromat': ['laundromat', 'laundry', 'wash and fold'],
            'landscaping': ['landscaping', 'lawn care', 'yard work'],
            'HVAC': ['hvac', 'heating', 'cooling', 'air conditioning'],
            'plumbing': ['plumbing', 'plumber'],
            'ecommerce': ['ecommerce', 'online store', 'e-commerce'],
            'food truck': ['food truck', 'mobile food'],
            'mobile business': ['mobile', 'route', 'delivery']
        }
        
        for industry, keywords in industry_keywords.items():
            if any(keyword in text for keyword in keywords):
                return industry
        
        return 'Other'
    
    def extract_revenue(self, description):
        """Extract revenue information from description"""
        if not description:
            return None
        
        # Look for revenue patterns
        revenue_patterns = [
            r'revenue[:\s]*\$?([0-9,]+)',
            r'gross[:\s]*\$?([0-9,]+)',
            r'sales[:\s]*\$?([0-9,]+)',
            r'income[:\s]*\$?([0-9,]+)'
        ]
        
        for pattern in revenue_patterns:
            match = re.search(pattern, description.lower())
            if match:
                return self.parse_price(match.group(1))
        
        return None
    
    def extract_cash_flow(self, description):
        """Extract cash flow information from description"""
        if not description:
            return None
        
        # Look for cash flow patterns
        cash_flow_patterns = [
            r'cash flow[:\s]*\$?([0-9,]+)',
            r'net income[:\s]*\$?([0-9,]+)',
            r'profit[:\s]*\$?([0-9,]+)',
            r'earnings[:\s]*\$?([0-9,]+)'
        ]
        
        for pattern in cash_flow_patterns:
            match = re.search(pattern, description.lower())
            if match:
                return self.parse_price(match.group(1))
        
        return None

