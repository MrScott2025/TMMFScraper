import re
import logging
from typing import Dict, Any, Optional

class DataNormalizer:
    """Utility for normalizing and filtering lead data"""
    
    def __init__(self, filter_config):
        self.filter_config = filter_config
        self.logger = logging.getLogger(self.__class__.__name__)
        
    def normalize(self, lead_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Normalize lead data to standard format"""
        try:
            normalized = {
                'business_name': self.normalize_text(lead_data.get('business_name', '')),
                'listing_title': self.normalize_text(lead_data.get('listing_title', '')),
                'platform': lead_data.get('platform', ''),
                'industry': self.normalize_industry(lead_data.get('industry', '')),
                'price': self.normalize_price(lead_data.get('price')),
                'revenue': self.normalize_price(lead_data.get('revenue')),
                'cash_flow': self.normalize_price(lead_data.get('cash_flow')),
                'city': self.normalize_text(lead_data.get('city', '')),
                'state': self.normalize_state(lead_data.get('state', '')),
                'location': self.normalize_text(lead_data.get('location', '')),
                'contact_name': self.normalize_text(lead_data.get('contact_name', '')),
                'contact_email': self.normalize_email(lead_data.get('contact_email', '')),
                'contact_phone': self.normalize_phone(lead_data.get('contact_phone', '')),
                'url': lead_data.get('url', ''),
                'description': self.normalize_description(lead_data.get('description', '')),
                'score': 0,  # Will be set by scorer
                'status': 'New',
                'notes': '',
                'platform_specific': lead_data.get('platform_specific', {})
            }
            
            # Ensure required fields are not empty
            if not normalized['listing_title'] or not normalized['platform']:
                return None
            
            return normalized
            
        except Exception as e:
            self.logger.error(f"Error normalizing lead: {str(e)}")
            return None
    
    def passes_filters(self, lead: Dict[str, Any]) -> bool:
        """Check if lead passes all configured filters"""
        try:
            # Price filter
            if not self.passes_price_filter(lead):
                return False
            
            # Revenue filter
            if not self.passes_revenue_filter(lead):
                return False
            
            # Cash flow filter
            if not self.passes_cash_flow_filter(lead):
                return False
            
            # Industry filter
            if not self.passes_industry_filter(lead):
                return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error checking filters: {str(e)}")
            return False
    
    def normalize_text(self, text: str) -> str:
        """Normalize text fields"""
        if not text:
            return ""
        
        # Clean up whitespace and special characters
        text = re.sub(r'\s+', ' ', str(text).strip())
        text = re.sub(r'[^\w\s\-\.\,\(\)]', '', text)
        
        return text
    
    def normalize_description(self, description: str) -> str:
        """Normalize description field"""
        if not description:
            return ""
        
        # Limit length and clean up
        description = str(description)[:1500]  # Limit to 1500 chars
        description = re.sub(r'\s+', ' ', description.strip())
        
        return description
    
    def normalize_price(self, price) -> Optional[float]:
        """Normalize price fields"""
        if price is None:
            return None
        
        try:
            # Handle string prices
            if isinstance(price, str):
                # Remove currency symbols and commas
                price_clean = re.sub(r'[^\d\.]', '', price)
                if not price_clean:
                    return None
                price = float(price_clean)
            
            # Convert to float and validate
            price = float(price)
            
            # Sanity check - prices should be reasonable
            if price < 0 or price > 100000000:  # 100M max
                return None
            
            return price
            
        except (ValueError, TypeError):
            return None
    
    def normalize_industry(self, industry: str) -> str:
        """Normalize industry field"""
        if not industry:
            return "Other"
        
        # Map common variations to standard names
        industry_mapping = {
            'car wash': ['car wash', 'auto wash', 'vehicle wash'],
            'detailing': ['detailing', 'auto detail', 'car detail'],
            'cleaning': ['cleaning', 'janitorial', 'maid service'],
            'restaurant': ['restaurant', 'cafe', 'diner', 'food service'],
            'ecommerce': ['ecommerce', 'e-commerce', 'online store'],
            'convenience store': ['convenience', 'corner store', 'mini mart'],
            'gas station': ['gas station', 'fuel station', 'petrol'],
            'laundromat': ['laundromat', 'laundry', 'wash and fold'],
            'landscaping': ['landscaping', 'lawn care', 'yard work'],
            'mobile business': ['mobile', 'food truck', 'route']
        }
        
        industry_lower = industry.lower()
        
        for standard_name, variations in industry_mapping.items():
            if any(var in industry_lower for var in variations):
                return standard_name
        
        return industry.title()
    
    def normalize_state(self, state: str) -> str:
        """Normalize state field"""
        if not state:
            return ""
        
        # Map abbreviations to full names
        state_mapping = {
            'FL': 'Florida',
            'MI': 'Michigan'
        }
        
        state = state.strip().upper()
        return state_mapping.get(state, state.title())
    
    def normalize_email(self, email: str) -> str:
        """Normalize email field"""
        if not email:
            return ""
        
        email = email.strip().lower()
        
        # Basic email validation
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if re.match(email_pattern, email):
            return email
        
        return ""
    
    def normalize_phone(self, phone: str) -> str:
        """Normalize phone field"""
        if not phone:
            return ""
        
        # Extract digits only
        digits = re.sub(r'[^\d]', '', str(phone))
        
        # US phone numbers should have 10 digits
        if len(digits) == 10:
            return f"({digits[:3]}) {digits[3:6]}-{digits[6:]}"
        elif len(digits) == 11 and digits[0] == '1':
            return f"({digits[1:4]}) {digits[4:7]}-{digits[7:]}"
        
        return phone  # Return original if can't normalize
    
    def passes_price_filter(self, lead: Dict[str, Any]) -> bool:
        """Check if lead passes price filter"""
        price = lead.get('price')
        if price is None:
            return True  # Allow leads without price info
        
        price_config = self.filter_config.get('price', {})
        min_price = price_config.get('min', 0)
        max_price = price_config.get('max', float('inf'))
        
        return min_price <= price <= max_price
    
    def passes_revenue_filter(self, lead: Dict[str, Any]) -> bool:
        """Check if lead passes revenue filter"""
        revenue = lead.get('revenue')
        if revenue is None:
            return True  # Allow leads without revenue info
        
        min_revenue = self.filter_config.get('revenue', {}).get('min', 0)
        return revenue >= min_revenue
    
    def passes_cash_flow_filter(self, lead: Dict[str, Any]) -> bool:
        """Check if lead passes cash flow filter"""
        cash_flow = lead.get('cash_flow')
        if cash_flow is None:
            return True  # Allow leads without cash flow info
        
        min_cash_flow = self.filter_config.get('cash_flow', {}).get('min', 0)
        return cash_flow >= min_cash_flow
    
    def passes_industry_filter(self, lead: Dict[str, Any]) -> bool:
        """Check if lead passes industry filter"""
        industry = lead.get('industry', '').lower()
        if not industry or industry == 'other':
            return True  # Allow unknown industries
        
        target_industries = self.filter_config.get('industries', [])
        if not target_industries:
            return True  # No industry filter configured
        
        # Check if industry matches any target industry
        for target in target_industries:
            if target.lower() in industry or industry in target.lower():
                return True
        
        return False
    
    def get_filter_summary(self, lead: Dict[str, Any]) -> str:
        """Get summary of which filters the lead passes/fails"""
        summary = []
        
        if not self.passes_price_filter(lead):
            summary.append("Price filter failed")
        
        if not self.passes_revenue_filter(lead):
            summary.append("Revenue filter failed")
        
        if not self.passes_cash_flow_filter(lead):
            summary.append("Cash flow filter failed")
        
        if not self.passes_industry_filter(lead):
            summary.append("Industry filter failed")
        
        return "; ".join(summary) if summary else "All filters passed"

