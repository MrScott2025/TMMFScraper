import re
import logging

class LeadScorer:
    """AI-enhanced lead scoring system using NLP keyword analysis"""
    
    def __init__(self, scoring_config):
        self.scoring_config = scoring_config
        self.logger = logging.getLogger(self.__class__.__name__)
        
    def score_lead(self, lead):
        """Calculate lead score based on title and description"""
        try:
            # Combine title and description for analysis
            text = f"{lead.get('listing_title', '')} {lead.get('description', '')}".lower()
            
            score = 0.0
            score_details = {}
            
            # Apply keyword-based scoring
            for keyword, weight in self.scoring_config.items():
                if keyword == 'missing_contact':
                    # Check if contact info is missing
                    if self.has_missing_contact(lead):
                        score += weight
                        score_details[keyword] = weight
                elif keyword == 'price_above_max':
                    # Check if price is above maximum
                    if self.is_price_above_max(lead):
                        score += weight
                        score_details[keyword] = weight
                else:
                    # Check for keyword presence
                    keyword_count = self.count_keyword_occurrences(text, keyword)
                    if keyword_count > 0:
                        # Apply weight, but cap the bonus for multiple occurrences
                        keyword_score = min(weight * keyword_count, weight * 2)
                        score += keyword_score
                        score_details[keyword] = keyword_score
            
            # Apply additional scoring factors
            score += self.score_urgency_indicators(text)
            score += self.score_business_quality(text)
            score += self.score_financial_transparency(lead)
            
            # Ensure score is within reasonable bounds (0-10)
            final_score = max(0, min(10, score))
            
            self.logger.debug(f"Lead scored {final_score:.1f}: {lead.get('listing_title', 'Unknown')}")
            
            return round(final_score, 1)
            
        except Exception as e:
            self.logger.error(f"Error scoring lead: {str(e)}")
            return 0.0
    
    def count_keyword_occurrences(self, text, keyword):
        """Count occurrences of keyword in text"""
        # Handle multi-word keywords
        if ' ' in keyword:
            return len(re.findall(re.escape(keyword), text))
        else:
            # Use word boundaries for single words
            pattern = r'\b' + re.escape(keyword) + r'\b'
            return len(re.findall(pattern, text))
    
    def has_missing_contact(self, lead):
        """Check if lead is missing contact information"""
        email = lead.get('contact_email')
        phone = lead.get('contact_phone')
        
        # Consider contact missing if both email and phone are empty
        return not email and not phone
    
    def is_price_above_max(self, lead):
        """Check if asking price is above maximum threshold"""
        price = lead.get('price')
        if not price:
            return False
        
        # Use 1M as default max if not specified
        max_price = 1000000
        return price > max_price
    
    def score_urgency_indicators(self, text):
        """Score based on urgency indicators"""
        urgency_keywords = [
            'urgent', 'asap', 'quick sale', 'immediate', 'fast closing',
            'need to sell', 'time sensitive', 'deadline', 'relocating',
            'health issues', 'family reasons'
        ]
        
        urgency_score = 0
        for keyword in urgency_keywords:
            if keyword in text:
                urgency_score += 0.5
        
        return min(urgency_score, 1.5)  # Cap at 1.5 points
    
    def score_business_quality(self, text):
        """Score based on business quality indicators"""
        quality_indicators = {
            'positive': [
                'profitable', 'growing', 'established', 'loyal customers',
                'repeat business', 'strong brand', 'good location',
                'trained staff', 'systems in place', 'passive income'
            ],
            'negative': [
                'struggling', 'declining', 'needs work', 'fixer upper',
                'high maintenance', 'seasonal', 'competitive market'
            ]
        }
        
        quality_score = 0
        
        # Positive indicators
        for indicator in quality_indicators['positive']:
            if indicator in text:
                quality_score += 0.3
        
        # Negative indicators
        for indicator in quality_indicators['negative']:
            if indicator in text:
                quality_score -= 0.2
        
        return max(-1.0, min(quality_score, 2.0))  # Cap between -1 and 2
    
    def score_financial_transparency(self, lead):
        """Score based on financial information availability"""
        transparency_score = 0
        
        # Bonus for having revenue information
        if lead.get('revenue'):
            transparency_score += 0.5
        
        # Bonus for having cash flow information
        if lead.get('cash_flow'):
            transparency_score += 0.5
        
        # Bonus for having both
        if lead.get('revenue') and lead.get('cash_flow'):
            transparency_score += 0.3
        
        return transparency_score
    
    def get_score_explanation(self, lead):
        """Get detailed explanation of how score was calculated"""
        text = f"{lead.get('listing_title', '')} {lead.get('description', '')}".lower()
        explanation = []
        
        # Check each scoring factor
        for keyword, weight in self.scoring_config.items():
            if keyword == 'missing_contact':
                if self.has_missing_contact(lead):
                    explanation.append(f"Missing contact info: {weight}")
            elif keyword == 'price_above_max':
                if self.is_price_above_max(lead):
                    explanation.append(f"Price above max: {weight}")
            else:
                count = self.count_keyword_occurrences(text, keyword)
                if count > 0:
                    explanation.append(f"'{keyword}' ({count}x): +{weight}")
        
        # Add other factors
        urgency = self.score_urgency_indicators(text)
        if urgency > 0:
            explanation.append(f"Urgency indicators: +{urgency:.1f}")
        
        quality = self.score_business_quality(text)
        if quality != 0:
            explanation.append(f"Business quality: {quality:+.1f}")
        
        transparency = self.score_financial_transparency(lead)
        if transparency > 0:
            explanation.append(f"Financial transparency: +{transparency:.1f}")
        
        return "; ".join(explanation)

