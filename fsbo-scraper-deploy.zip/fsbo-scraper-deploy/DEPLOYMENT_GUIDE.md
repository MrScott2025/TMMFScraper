# 🚀 Railway Deployment Guide

## Step-by-Step Instructions

### 1. Get the Code
You have two options:

#### Option A: Download ZIP
1. Download this repository as a ZIP file
2. Extract it to your computer
3. Upload to your own GitHub repository

#### Option B: Fork Repository
1. Click "Fork" on the GitHub repository
2. This creates your own copy

### 2. Deploy to Railway

#### Sign Up for Railway
1. Go to [railway.app](https://railway.app)
2. Click "Login" → "Login with GitHub"
3. Authorize Railway to access your GitHub

#### Create New Project
1. Click "New Project"
2. Select "Deploy from GitHub repo"
3. Choose your fsbo-scraper repository
4. Click "Deploy Now"

### 3. Configure Deployment

Railway will automatically:
- ✅ Detect Python project
- ✅ Install dependencies from `requirements.txt`
- ✅ Set start command to `python app.py`
- ✅ Assign a public domain

**No manual configuration needed!**

### 4. Get Your URL

After deployment (2-3 minutes):
1. Go to your Railway project dashboard
2. Click "Settings" → "Domains"
3. Copy your app URL (looks like: `https://fsbo-scraper-production.up.railway.app`)

### 5. Test Your Deployment

#### Test Health Endpoint
Open in browser: `https://your-app.railway.app/api/health`

**Should show:**
```json
{"service":"FSBO Scraper","status":"healthy"}
```

#### Test API Endpoint
Use curl or Postman:
```bash
curl -X POST https://your-app.railway.app/api/fetch-leads \
  -H "Content-Type: application/json" \
  -d '{"scraper_settings": {"max_leads_per_run": 5}}'
```

### 6. Update Google Apps Script

In your Google Apps Script, update the URL:
```javascript
const SCRAPER_ENDPOINT = 'https://your-app.railway.app/api/fetch-leads';
```

### 7. Test Complete Integration

1. Run `testAPIConnection()` in Google Apps Script
2. Should show "✅ API connection successful!"
3. Click your "Pull 50 FSBO Leads Today" button
4. Leads should appear in your Google Sheet

## 🔧 Troubleshooting

### Deployment Fails
- Check Railway build logs
- Ensure `requirements.txt` is complete
- Verify `app.py` exists in root directory

### API Not Responding
- Check Railway application logs
- Verify the domain is correct
- Test health endpoint first

### Google Apps Script Errors
- Verify the endpoint URL is correct
- Check Apps Script execution logs
- Ensure proper permissions are granted

## 💰 Railway Pricing

- **Free Tier**: $5 credit per month (enough for testing)
- **Pro Plan**: $5/month (recommended for production)
- **Usage-based**: Only pay for what you use

## 🔄 Updates

To update your deployment:
1. Push changes to your GitHub repository
2. Railway automatically redeploys
3. No manual intervention needed

## 📊 Monitoring

Railway provides:
- Real-time logs
- Performance metrics
- Uptime monitoring
- Custom domains (Pro plan)

---

**Your FSBO scraper will be live and ready to generate leads!** 🎯

